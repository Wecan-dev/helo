<?php
/**
 * @package   solo
 * @copyright Copyright (c)2014-2020 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

define('AKEEBABACKUP_PRO', '0');
define('AKEEBABACKUP_VERSION', '7.4.0');
define('AKEEBABACKUP_DATE', '2020-11-17');