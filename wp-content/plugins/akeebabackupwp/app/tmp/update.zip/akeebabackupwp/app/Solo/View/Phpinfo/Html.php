<?php
/**
 * @package   solo
 * @copyright Copyright (c)2014-2020 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

namespace Solo\View\Phpinfo;

use Awf\Mvc\View;

/**
 * The view class for the Configuration view
 */
class Html extends View
{

}
